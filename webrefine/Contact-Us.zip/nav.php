	<!-- header -->
		<div class="header">
            <div class="logo" style="width: 30%;">
                <!--<h1><a href="#/"><span>N</span>du-system.net</a></h1>-->
                <a href="Home"> <img src="images/logo-2.PNG" style="width:40%" /></a>
            </div>   
			<div class="clearfix"> </div>
		</div>
		<!-- //header -->
		<!-- top-nav -->
	<nav class="cd-stretchy-nav edit-content">
			<a class="cd-nav-trigger" href="#0"> Menu <span aria-hidden="true"></span> </a>
			<ul>
				<li><a href="Home" class="scroll active"><span>HOME</span></a></li>
				<li><a href="About-Us"><span>WHO ARE WE</span></a></li>
				<li><a href="Our-Services"><span>OUR SERVICES</span></a></li>   
				<li><a href="Make-Buck"><span>MAKE A BUCK</span></a></li>
				<li><a href="Gallery"><span>GALLERY</span></a></li> 
				<li><a href="Contact-Us"><span>CONTACT US</span></a></li>
                <li><a href="Fearured-business"><span>FEARURED-BUSINESS</span></a></li> 
			</ul> 

        
			<span aria-hidden="true" class="stretchy-nav-bg"></span>
		</nav> 