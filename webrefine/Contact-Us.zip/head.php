<!DOCTYPE>
<html ng-app ="App">
<head>
 <title>
        Web Development ,Systems,Databases, Mobile Apps - Windows, Android and Iphone, Website for your company, Cheap Websites , Small Business Website , Email Accounts, South Africa, cheap websites in  south africa,cheap website design in johannesburg ,ndu systems,cheap website design, affordable website design packages
    </title>   <link rel="shortcut icon" href="images/icon.png">
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="        Web Development ,Systems,Databases, Mobile Apps - Windows, Android and Iphone, Website for your company, Cheap Websites , Small Business Website , Email Accounts, South Africa, cheap websites in  south africa,cheap website design in johannesburg ,ndu systems,cheap website design, affordable website design packages" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--// Meta tag Keywords -->
<!-- css files -->
<link rel="stylesheet" href="css/bootstrap.css"> <!-- Bootstrap-Core-CSS -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
<!-- //css files -->
<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Athiti:200,300,400,500,600,700&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">

    <!--Angular Components-->
    <script src="angularjs/config.js"></script>
    <script src="js/angular.min.js"></script>
    <script src="js/angular-route.js"></script>
    <script src="angularjs/app.js"></script>
    <!--<script src="routes/routes.js"></script>-->
    <!--/angular components-->
    <!--controllers-->
    <script src="controllers/homeController.js"></script>
    <!--/controllers-->

</head>